#pragma once
class movementinterface 
{
	public:
	virtual void movePiece(char *userMove) = 0;
};
